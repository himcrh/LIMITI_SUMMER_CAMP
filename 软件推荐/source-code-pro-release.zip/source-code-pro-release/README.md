# Source Code Pro

[Source Code Pro](http://adobe-fonts.github.io/source-code-pro/)
is a set of OpenType fonts that have been designed to work well
in user interface (UI) environments.

## Open source files

The fonts' source files and build instructions are available in the [repository's `master` branch](https://github.com/adobe-fonts/source-code-pro/tree/master).

## Getting involved

[Open an issue](https://github.com/adobe-fonts/source-code-pro/issues) or send a suggestion to Source Code's designer [Paul D. Hunt](mailto:opensourcefonts@adobe.com?subject=[GitHub]%20Source%20Code%20Pro), for consideration.

## Releases

* [Latest release](../../releases/latest)
* [All releases](../../releases)
